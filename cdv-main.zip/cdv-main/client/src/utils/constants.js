import abi from "./Transactions.json";

export const contractAddress = "0x8eD9E28c2255FDAaEE6EfCDDa07074489B2674E3";
export const contractABI = abi.abi;
